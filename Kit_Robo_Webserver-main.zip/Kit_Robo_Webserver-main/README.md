# kit_robo_webserver
Repositório referente ao Robô com Controle Remoto via Web Server.

O joystick deste projeto é uma adaptação do visto em: https://www.instructables.com/Making-a-Joystick-With-HTML-pure-JavaScript/
Nesta versão, o gerenciador é integrado ao main.ino do ESP e baseado no visto em https://randomnerdtutorials.com/esp8266-nodemcu-wi-fi-manager-asyncwebserver/.
O hardware e todas as conexões seguem identicos aos da versão anterior.
